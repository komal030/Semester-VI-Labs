from django.apps import AppConfig


class webappConfig(AppConfig):
    name = 'webapp'
