"""
Package for web1.
"""
