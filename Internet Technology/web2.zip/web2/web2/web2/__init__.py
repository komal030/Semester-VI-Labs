"""
Package for web2.
"""
